# multidfe_correction_round2.R
# script to calculate corrected alpha and omega_a using the new multiDFE output
# Alissa Williams
# June 2, 2022

# define Jukes-Cantor function
# from https://github.com/kousathanas/MultiDFE
# ***div.jukes***
# calculates Jukes-Cantor divergence.
# Input: x<-total sites,y<-site diffs
div.jukes<-function(x,y)
{
  d<-vector(length=length(x));
  for (i in 1:length(x))
  {
    if (y[i]<=0){d[i]=NA;next;}
    p=y[i]/x[i]
    if ((1-(4/3)*p)<0){d[i]=NA;next;}
    d[i]=(-3/4)*log(1-(4/3)*p)
  }
  
  return(d)
}

# get PopFlyData table
library(iMKT)
loadPopFly()

setwd("~/Desktop/pleiotropy_Dmelanogaster/MK_analyses/multiDFE_round2/final_figures/")

# subset the populations of interest
popral = subset(PopFlyData, Pop == "RAL")
popzi = subset(PopFlyData, Pop == "ZI")

# read in list of MultiDFE-outputted probabilities
probsplei = read.table("plei_fixation_multiDFE_RAL_lognormal_check.txt")
probsnonplei = read.table("nonplei_fixation_multiDFE_RAL_lognormal_check.txt")
probsdevo = read.table("devo_fixation_multiDFE_RAL_lognormal_check.txt")
colnames(probsplei) = c("GeneID", "fixprob")
colnames(probsnonplei) = c("GeneID", "fixprob")
colnames(probsdevo) = c("GeneID", "fixprob")

probsplei$class = "plei"
probsnonplei$class = "nonplei"
probsdevo$class = "devo"

#probsplei$class = "Pleiotropic"
#probsnonplei$class = "Non-plei Immune"
#probsdevo$class = "Non-plei Developmental"

#probs = probsplei
#probs = rbind(probsplei, probsnonplei)
probs = rbind(probsplei, probsnonplei, probsdevo)

# make columns for new values
# initiate as numeric so I don't have to deal with converting later
probs$pi = 0 # from popral
probs$p0 = 0 # from popral
probs$di = 0 # from popral
probs$d0 = 0 # from popral
probs$mi = 0 # from popral
probs$m0 = 0 # from popral
#probs$alpha = 0 # calculated
#probs$omegaA = 0 # calculated
# add in columns for corrected data
probs$dicorr = 0
probs$d0corr = 0
probs$alphacorr = 0
probs$omegaAcorr = 0
probs$alphaun = 0 # uncorrected
probs$omegaAun = 0 # uncorrected

# do corrections on RAL population data. will need to extract mi and m0 from PopFlyData subsets. 
# correction from MultiDFE GitHub page
for (i in 1:nrow(probs)){
  genename = probs[i,1]
  rowmatch = match(genename, popral$Name) # find row containing that gene ID
  pi = popral[rowmatch, 6]
  p0 = popral[rowmatch, 5]
  di = popral[rowmatch,7]
  d0 = popral[rowmatch,8]
  mi = popral[rowmatch, 10]
  m0 = popral[rowmatch, 11]
  probs[i,4] = pi
  probs[i,5] = p0
  probs[i,6] = di
  probs[i,7] = d0
  probs[i,8] = mi
  probs[i,9] = m0
  dcorr = div.jukes(c(mi, m0), c(di, d0)) # calculate both dicorr and d0corr at once
  probs[i, 10] = dcorr[1] # add dicorr
  probs[i, 11] = dcorr[2] # add d0corr
  fixprob = probs[i, 2]
  probs[i,12] = (dcorr[1] - (dcorr[2] * fixprob))/dcorr[1] # alpha calculation
  probs[i,13] = (dcorr[1] - (dcorr[2] * fixprob))/dcorr[2] # omega_a calculation
  probs[i,14] = (di - (d0 * fixprob))/di # uncorrected alpha calculation
  probs[i,15] = (di - (d0 * fixprob))/d0 # uncorrected omega_a calculation
}

write.table(probs, "all_values_RAL_lognormal_uncorrected.txt", quote = FALSE, row.names = FALSE)

# alpha
# subset those with actual numbers (not NaN or -Inf)
probsalpha = probs[!is.na(probs$alphacorr),]
probsalpha2 = probsalpha[!is.infinite(probsalpha$alphacorr),]

# only include numbers above 0 (negative numbers violate assumptions for alpha)
probsalpha3 = probsalpha2[probsalpha2$alphacorr >= 0,]
pdf("alphacorr_all_nonegs_lognormal_boxplot_check.pdf")
ggplot(data = probsalpha3, aes(x = class, y = alphacorr)) + geom_boxplot()
dev.off()
kruskal.test(alphacorr ~ class, data = probsalpha3)

# uncorrected alpha
# subset those with actual numbers (not NaN or -Inf)
probsalpha = probs[!is.na(probs$alphaun),]
probsalpha2 = probsalpha[!is.infinite(probsalpha$alphaun),]

# only include numbers above 0 (negative numbers violate assumptions for alpha)
probsalpha3 = probsalpha2[probsalpha2$alphaun >= 0,]
pdf("alphaun_all_nonegs_lognormal_boxplot_uncorrected.pdf")
ggplot(data = probsalpha3, aes(x = class, y = alphaun)) + geom_boxplot()
dev.off()
kruskal.test(alphaun ~ class, data = probsalpha3)


# omegaA
probsomegaA = probs[!is.na(probs$omegaAcorr),]
probsomegaA2 = probsomegaA[!is.infinite(probsomegaA$omegaAcorr),]
probsomegaA3 = probsomegaA2[probsomegaA2$omegaAcorr >= 0,]
pdf("omegaAcorr_all_nonegs_lognormal_violin.pdf")
ggplot(data = probsomegaA2, aes(x = class, y = alphacorr)) + geom_violin()
dev.off()
kruskal.test(omegaAcorr ~ class, data = probsomegaA3) 
dunn.test(probsomegaA2$omegaAcorr, probsomegaA2$class, method="bh")


# means
mean(probsalpha3$alphacorr[probsalpha3$class == "nonplei"])
mean(probsalpha3$alphacorr[probsalpha3$class == "plei"])
mean(probsalpha3$alphacorr[probsalpha3$class == "devo"])

mean(probsomegaA2$omegaAcorr[probsomegaA2$class == "nonplei"])
mean(probsomegaA2$omegaAcorr[probsomegaA2$class == "plei"])
mean(probsomegaA2$omegaAcorr[probsomegaA2$class == "devo"])

# medians
median(probsalpha3$alphacorr[probsalpha3$class == "nonplei"])
median(probsalpha3$alphacorr[probsalpha3$class == "plei"])
median(probsalpha3$alphacorr[probsalpha3$class == "devo"])

median(probsomegaA2$omegaAcorr[probsomegaA2$class == "nonplei"])
median(probsomegaA2$omegaAcorr[probsomegaA2$class == "plei"])
median(probsomegaA2$omegaAcorr[probsomegaA2$class == "devo"])

# count number of entries
nrow(subset(probsalpha3, probsalpha3$class == "nonplei"))
nrow(subset(probsalpha3, probsalpha3$class == "plei"))
nrow(subset(probsalpha3, probsalpha3$class == "devo"))

#first, set the order of factors:
dataframe = probsalpha3
dataframe$class = as.factor(dataframe$class)
dataframe$class = factor(dataframe$class, levels = c("nonplei","plei","devo"))
#Then:
pdf("alpha_corrected_boxplot_nonegs_RAL_round2.pdf")
Set2_colors <- brewer.pal(3, "Set2")
aq <- ggplot(dataframe, aes(class, as.numeric(alphacorr), fill = class))
aq +
  geom_boxplot() +
  theme_classic() +
  scale_fill_brewer(palette = "Set2") +
  theme(plot.title = element_text(size=11)) +
  ylab("alpha") +
  xlab("Gene Type") +
  theme(axis.text.y   = element_text(size=14),
        axis.text.x   = element_text(size=14),
        axis.title.y  = element_text(size=14),
        axis.title.x  = element_text(size=14),
        panel.background = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(colour = "black"))

dev.off()


## ZI population ##

setwd("~/Desktop/pleiotropy_Dmelanogaster/MK_analyses/multiDFE_round2/ZI/")

# read in list of MultiDFE-outputted probabilities
probsplei2 = read.table("plei_fixation_multiDFE_ZI_lognormal_check.txt")
probsnonplei2 = read.table("nonplei_fixation_multiDFE_ZI_lognormal_check.txt")
probsdevo2 = read.table("devo_fixation_multiDFE_ZI_lognormal_check.txt")
colnames(probsplei2) = c("GeneID", "fixprob")
colnames(probsnonplei2) = c("GeneID", "fixprob")
colnames(probsdevo2) = c("GeneID", "fixprob")

probsplei2$class = "plei"
probsnonplei2$class = "nonplei"
probsdevo2$class = "devo"

probs2 = rbind(probsplei2, probsnonplei2, probsdevo2)

# make columns for new values
# initiate as numeric so I don't have to deal with converting later
probs2$pi = 0 # from popral
probs2$p0 = 0 # from popral
probs2$di = 0 # from popral
probs2$d0 = 0 # from popral
probs2$mi = 0 # from popral
probs2$m0 = 0 # from popral
#probs$alpha = 0 # calculated
#probs$omegaA = 0 # calculated
# add in columns for corrected data
probs2$dicorr = 0
probs2$d0corr = 0
probs2$alphacorr = 0
probs2$omegaAcorr = 0

# do corrections on RAL population data. will need to extract mi and m0 from PopFlyData subsets. 
# correction from MultiDFE GitHub page
for (i in 1:nrow(probs2)){
  genename = probs2[i,1]
  rowmatch = match(genename, popzi$Name) # find row containing that gene ID
  pi = popzi[rowmatch, 6]
  p0 = popzi[rowmatch, 5]
  di = popzi[rowmatch,7]
  d0 = popzi[rowmatch,8]
  mi = popzi[rowmatch, 10]
  m0 = popzi[rowmatch, 11]
  probs2[i,4] = pi
  probs2[i,5] = p0
  probs2[i,6] = di
  probs2[i,7] = d0
  probs2[i,8] = mi
  probs2[i,9] = m0
  dcorr = div.jukes(c(mi, m0), c(di, d0)) # calculate both dicorr and d0corr at once
  probs2[i, 10] = dcorr[1] # add dicorr
  probs2[i, 11] = dcorr[2] # add d0corr
  fixprob = probs2[i, 2]
  probs2[i,12] = (dcorr[1] - (dcorr[2] * fixprob))/dcorr[1] # alpha calculation
  probs2[i,13] = (dcorr[1] - (dcorr[2] * fixprob))/dcorr[2] # omega_a calculation
}

write.table(probs2, "all_values_ZI_lognormal_check.txt", quote = FALSE, row.names = FALSE)

# alpha
# subset those with actual numbers (not NaN or -Inf)
probsalphazi = probs2[!is.na(probs2$alphacorr),]
probsalpha2zi = probsalphazi[!is.infinite(probsalphazi$alphacorr),]

# only include numbers above 0 (negative numbers violate assumptions for alpha)
probsalpha3zi = probsalpha2zi[probsalpha2zi$alphacorr >= 0,]
pdf("alphacorr_all_nonegs_lognormal_boxplot_check.pdf")
ggplot(data = probsalpha3zi, aes(x = class, y = alphacorr)) + geom_boxplot()
dev.off()
kruskal.test(alphacorr ~ class, data = probsalpha3zi)


# omegaA
probsomegaAzi = probs2[!is.na(probs2$omegaAcorr),]
probsomegaA2zi = probsomegaAzi[!is.infinite(probsomegaAzi$omegaAcorr),]
probsomegaA3zi = probsomegaA2zi[probsomegaA2zi$omegaAcorr >= 0,]
kruskal.test(omegaAcorr ~ class, data = probsomegaA3zi) 
dunn.test(probsomegaA2zi$omegaAcorr, probsomegaA2zi$class, method="bh")

#first, set the order of factors:
dataframe = probsalpha3zi
dataframe$class = as.factor(dataframe$class)
dataframe$class = factor(dataframe$class, levels = c("nonplei","plei","devo"))
#Then:
pdf("alpha_corrected_boxplot_nonegs_ZI_round2.pdf")
Set2_colors <- brewer.pal(3, "Set2")
aq <- ggplot(dataframe, aes(class, as.numeric(alphacorr), fill = class))
aq +
  geom_boxplot() +
  theme_classic() +
  scale_fill_brewer(palette = "Set2") +
  theme(plot.title = element_text(size=11)) +
  ylab("alpha") +
  xlab("Gene Type") +
  theme(axis.text.y   = element_text(size=14),
        axis.text.x   = element_text(size=14),
        axis.title.y  = element_text(size=14),
        axis.title.x  = element_text(size=14),
        panel.background = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(colour = "black"))

dev.off()

# means
mean(probsalpha3zi$alphacorr[probsalpha3zi$class == "nonplei"])
mean(probsalpha3zi$alphacorr[probsalpha3zi$class == "plei"])
mean(probsalpha3zi$alphacorr[probsalpha3zi$class == "devo"])

mean(probsomegaA2zi$omegaAcorr[probsomegaA2zi$class == "nonplei"])
mean(probsomegaA2zi$omegaAcorr[probsomegaA2zi$class == "plei"])
mean(probsomegaA2zi$omegaAcorr[probsomegaA2zi$class == "devo"])

# medians
median(probsalpha3zi$alphacorr[probsalpha3zi$class == "nonplei"])
median(probsalpha3zi$alphacorr[probsalpha3zi$class == "plei"])
median(probsalpha3zi$alphacorr[probsalpha3zi$class == "devo"])

median(probsomegaA2zi$omegaAcorr[probsomegaA2zi$class == "nonplei"])
median(probsomegaA2zi$omegaAcorr[probsomegaA2zi$class == "plei"])
median(probsomegaA2zi$omegaAcorr[probsomegaA2zi$class == "devo"])

# count number of entries
nrow(subset(probsalpha3zi, probsalpha3zi$class == "nonplei"))
nrow(subset(probsalpha3zi, probsalpha3zi$class == "plei"))
nrow(subset(probsalpha3zi, probsalpha3zi$class == "devo"))



