# multidfe_sum_tables.R
# script to use final tables made by multidfe_sum.R
# Alissa Williams
# June 22, 2022

library(ggplot2)
library(dunn.test)

setwd("~/Desktop/pleiotropy_Dmelanogaster/MK_analyses/multiDFE_sum/")

probsral = read.table("all_values_RAL_lognormal_sum_plei_three_classes.txt", header = TRUE)
probszi = read.table("all_values_ZI_lognormal_sum_plei_three_classes.txt", header = TRUE)

## plots for RAL ##

#first, set the order of factors:
dataframeral = probsral
dataframeral$class = as.factor(dataframeral$class)
dataframeral$class = factor(dataframeral$class, levels = c("nonplei","plei","devo"))

#alpha
pdf("alpha_corrected_violinplot_RAL_sum_v2.pdf")
Set2_colors <- brewer.pal(3, "Set2")
aq <- ggplot(dataframeral, aes(class, as.numeric(alphacorr), fill = class))
aq +
  geom_violin() +
  geom_boxplot(width=0.1, color="black", alpha=0.2) +
  theme_classic() +
  scale_fill_brewer(palette = "Set2") +
  theme(plot.title = element_text(size=11)) +
  ylab("alpha") +
  xlab("Gene Type") +
  ylim(0,1) +
  theme(axis.text.y   = element_text(size=14),
        axis.text.x   = element_text(size=14),
        axis.title.y  = element_text(size=14),
        axis.title.x  = element_text(size=14),
        panel.background = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(colour = "black"))

dev.off()

# omega_a
pdf("omegaA_corrected_violinplot_RAL_sum_v2.pdf")
Set2_colors <- brewer.pal(3, "Set2")
aq <- ggplot(dataframeral, aes(class, as.numeric(omegaAcorr), fill = class))
aq +
  geom_violin() +
  geom_boxplot(width=0.1, color="black", alpha=0.2) +
  theme_classic() +
  scale_fill_brewer(palette = "Set2") +
  theme(plot.title = element_text(size=11)) +
  ylab("omega_a") +
  xlab("Gene Type") +
  ylim(0,1) +
  theme(axis.text.y   = element_text(size=14),
        axis.text.x   = element_text(size=14),
        axis.title.y  = element_text(size=14),
        axis.title.x  = element_text(size=14),
        panel.background = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(colour = "black"))

dev.off()


## plots for ZI ##

#first, set the order of factors:
dataframezi = probszi
dataframezi$class = as.factor(dataframezi$class)
dataframezi$class = factor(dataframezi$class, levels = c("nonplei","plei","devo"))

# alpha
pdf("alpha_corrected_violinplot_ZI_sum_V2.pdf")
Set2_colors <- brewer.pal(3, "Set2")
aq <- ggplot(dataframezi, aes(class, as.numeric(alphacorr), fill = class))
aq +
  geom_violin() +
  geom_boxplot(width=0.1, color="black", alpha=0.2) +
  theme_classic() +
  scale_fill_brewer(palette = "Set2") +
  theme(plot.title = element_text(size=11)) +
  ylab("alpha") +
  xlab("Gene Type") +
  ylim(0,1) +
  theme(axis.text.y   = element_text(size=14),
        axis.text.x   = element_text(size=14),
        axis.title.y  = element_text(size=14),
        axis.title.x  = element_text(size=14),
        panel.background = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(colour = "black"))

dev.off()

# omega_a
pdf("omegaA_corrected_violinplot_ZI_sum_v2.pdf")
Set2_colors <- brewer.pal(3, "Set2")
aq <- ggplot(dataframezi, aes(class, as.numeric(omegaAcorr), fill = class))
aq +
  geom_violin() +
  geom_boxplot(width=0.1, color="black", alpha=0.2) +
  theme_classic() +
  scale_fill_brewer(palette = "Set2") +
  theme(plot.title = element_text(size=11)) +
  ylab("omega_a") +
  xlab("Gene Type") +
  ylim(0,1) +
  theme(axis.text.y   = element_text(size=14),
        axis.text.x   = element_text(size=14),
        axis.title.y  = element_text(size=14),
        axis.title.x  = element_text(size=14),
        panel.background = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(colour = "black"))

dev.off()

# statistical tests

# RAL
kruskal.test(alphacorr ~ class, data = probsral) # p-value < 2.2e-16 
dunn.test(probsral$alphacorr, probsral$class, method="bh") # all pairwise comparisons are significant
kruskal.test(omegaAcorr ~ class, data = probsral) # p-value < 3.202e-13 
dunn.test(probsral$omegaAcorr, probsral$class, method="bh") # all pairwise comparisons are significant

# ZI
kruskal.test(alphacorr ~ class, data = probszi) # p-value < 2.2e-16 
dunn.test(probszi$alphacorr, probszi$class, method="bh") # all pairwise comparisons are significant
kruskal.test(omegaAcorr ~ class, data = probszi) # p-value < 2.2e-16
dunn.test(probszi$omegaAcorr, probszi$class, method="bh") # devo and nonplei are not significantly different, other comparisons are


# medians
median(probsral$alphacorr[probsral$class == "nonplei"])
median(probsral$alphacorr[probsral$class == "plei"])
median(probsral$alphacorr[probsral$class == "devo"])

median(probszi$alphacorr[probszi$class == "nonplei"])
median(probszi$alphacorr[probszi$class == "plei"])
median(probszi$alphacorr[probszi$class == "devo"])

median(probsral$omegaAcorr[probsral$class == "nonplei"])
median(probsral$omegaAcorr[probsral$class == "plei"])
median(probsral$omegaAcorr[probsral$class == "devo"])

median(probszi$omegaAcorr[probszi$class == "nonplei"])
median(probszi$omegaAcorr[probszi$class == "plei"])
median(probszi$omegaAcorr[probszi$class == "devo"])


